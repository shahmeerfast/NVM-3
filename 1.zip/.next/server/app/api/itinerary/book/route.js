const CHUNK_PUBLIC_PATH = "server/app/api/itinerary/book/route.js";
const runtime = require("../../../../chunks/[turbopack]_runtime.js");
runtime.loadChunk("server/chunks/node_modules_next_3ad591._.js");
runtime.loadChunk("server/chunks/node_modules_nodemailer_a9f338._.js");
runtime.loadChunk("server/chunks/node_modules_2495da._.js");
runtime.loadChunk("server/chunks/[root of the server]__4e9cb6._.js");
runtime.loadChunk("server/chunks/_f8531a._.js");
runtime.getOrInstantiateRuntimeModule("[project]/.next-internal/server/app/api/itinerary/book/route/actions.js [app-rsc] (ecmascript)", CHUNK_PUBLIC_PATH);
module.exports = runtime.getOrInstantiateRuntimeModule("[project]/node_modules/next/dist/esm/build/templates/app-route.js { INNER_APP_ROUTE => \"[project]/src/app/api/itinerary/book/route.ts [app-route] (ecmascript)\" } [app-route] (ecmascript)", CHUNK_PUBLIC_PATH).exports;
