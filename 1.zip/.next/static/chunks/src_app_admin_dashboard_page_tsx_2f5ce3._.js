(globalThis.TURBOPACK = globalThis.TURBOPACK || []).push([
    "static/chunks/src_app_admin_dashboard_page_tsx_2f5ce3._.js",
    {},
]);
(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
  "path": "static/chunks/src_app_admin_dashboard_page_tsx_2f5ce3._.js",
  "chunks": [
    "static/chunks/_b6a573._.js"
  ],
  "source": "dynamic"
});
