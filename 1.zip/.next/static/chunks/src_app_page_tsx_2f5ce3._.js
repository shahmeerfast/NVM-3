(globalThis.TURBOPACK = globalThis.TURBOPACK || []).push([
    "static/chunks/src_app_page_tsx_2f5ce3._.js",
    {},
]);
(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
  "path": "static/chunks/src_app_page_tsx_2f5ce3._.js",
  "chunks": [
    "static/chunks/src_a066d5._.js",
    "static/chunks/node_modules_7f5d5a._.js",
    "static/chunks/node_modules_react-toastify_dist_ReactToastify_391de2.css"
  ],
  "source": "dynamic"
});
