(globalThis.TURBOPACK = globalThis.TURBOPACK || []).push([
    "static/chunks/src_app_winery_[id]_page_tsx_2f5ce3._.js",
    {},
]);
(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
  "path": "static/chunks/src_app_winery_[id]_page_tsx_2f5ce3._.js",
  "chunks": [
    "static/chunks/src_9093f3._.js",
    "static/chunks/node_modules_leaflet_dist_bed773._.js",
    "static/chunks/node_modules_leaflet-routing-machine_dist_leaflet-routing-machine_80e1da.js",
    "static/chunks/node_modules_axios_lib_c4c49c._.js",
    "static/chunks/node_modules_c2bc37._.js",
    "static/chunks/node_modules_leaflet_dist_leaflet_88e19f.css"
  ],
  "source": "dynamic"
});
