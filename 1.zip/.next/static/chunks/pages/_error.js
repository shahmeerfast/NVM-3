__turbopack_load_page_chunks__("/_error", [
  "static/chunks/[root of the server]__31723f._.js",
  "static/chunks/node_modules_react-dom_82bb97._.js",
  "static/chunks/node_modules_beb007._.js",
  "static/chunks/[root of the server]__2e1cf5._.js",
  "static/chunks/pages__error_5771e1._.js",
  "static/chunks/pages__error_b8c4c3._.js"
])
