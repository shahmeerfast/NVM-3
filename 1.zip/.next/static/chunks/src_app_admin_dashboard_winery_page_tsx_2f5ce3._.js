(globalThis.TURBOPACK = globalThis.TURBOPACK || []).push([
    "static/chunks/src_app_admin_dashboard_winery_page_tsx_2f5ce3._.js",
    {},
]);
(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
  "path": "static/chunks/src_app_admin_dashboard_winery_page_tsx_2f5ce3._.js",
  "chunks": [
    "static/chunks/node_modules_a98f56._.css",
    "static/chunks/src_3ef546._.js",
    "static/chunks/node_modules_leaflet_dist_leaflet-src_e7e140.js",
    "static/chunks/node_modules_react-select_dist_aeaafd._.js",
    "static/chunks/node_modules_axios_lib_c4c49c._.js",
    "static/chunks/node_modules_1fbbbc._.js"
  ],
  "source": "dynamic"
});
